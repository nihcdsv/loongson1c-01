
#include <rtthread.h>  
#include <mpu6xxx.h>

#include <string.h>
#include <stdio.h>
#include "ssd1306.h"
 

#include <sensor.h>

#define DBG_LEVEL   DBG_LOG
#include <rtdbg.h>
#define LOG_TAG                "example.hr"
/* Default configuration, please change according to the actual situation, support i2c and spi device name */
#define MPU6XXX_DEVICE_NAME  "i2c1"
/* 定时器的控制块 */
static rt_timer_t timer1;
static rt_timer_t timer2;


int16_t ax, ay, az;
int16_t gx, gy, gz;
int axoffs,ayoffs,azoffs;
float rax,ray,raz;
float ax0,ay0,az0;
float ax1,ay1,az1;
/* Test function */
double t1;
double t0;
double t;
int sum;
int count=0;
/* Test function */
    struct mpu6xxx_device *dev;
    struct mpu6xxx_3axes accel, gyro;
    int ge,shi,bai,qian;




static int mpu6xxx_st()
{
 
  

    /* Initialize mpu6xxx, The parameter is RT_NULL, means auto probing for i2c*/
    dev = mpu6xxx_init(MPU6XXX_DEVICE_NAME, RT_NULL);

    if (dev == RT_NULL)
    {
        rt_kprintf("mpu6xxx init failed\n");
        return -1;
    }
    rt_kprintf("mpu6xxx init succeed\n");

    
    return 1;
}
void jisuan()
{
      sum=abs(abs(ax1)+abs(ay1)+abs(az1));
      rt_kprintf("mpu6xxx %d\n",sum);
      if(sum>18)
      {
      count++;
      sum=0;
      }
      if(count<10) {ge=count; shi=0; bai=0;}
      if((count>=10)&&(count<100)) { ge=count%10; shi=count/10; bai=0;}
      if((count>=100)&&(count<1000)) {ge=count%100%10; shi=count%100/10; bai=count/100;}
      if(count>1000)          {ge=0;shi=0;bai=0;}
}
void getoffs()
{
      int16_t ax, ay, az;
      int16_t gx, gy, gz;
      long int axsum=0;
      long int aysum=0;
      long int azsum=0;
      int i;
          for(i=1;i<=2000;i++)
          {
              mpu6xxx_get_accel(dev, &accel);
                ax=accel.x;
                ay=accel.y;
                az=accel.z ;
              axsum=ax+axsum;
              aysum=ay+aysum;
              azsum=az+azsum-16384;
          }
      axoffs=-axsum/2000;
      ayoffs=-aysum/2000;
      azoffs=-azsum/2000;
}
static int mpu6xxx_test()
{

    int i;

    

    
        mpu6xxx_get_accel(dev, &accel);
        mpu6xxx_get_gyro(dev, &gyro);
    ax=accel.x;
    ay=accel.y;
    az=accel.z ;
        rt_kprintf("accel.x = %3d, accel.y = %3d, accel.z = %3d ", ax, ay, az );
       // rt_kprintf("gyro.x = %3d gyro.y = %3d, gyro.z = %3d\n", gyro.x, gyro.y, gyro.z);
    ax=ax+axoffs;
    ay=ay+ayoffs;
    az=az+azoffs;
    rax=ax;
    ray=ay;
    raz=az;
    ax1=(rax/16384)*9.80;
    ay1=(ray/16384)*9.80;
    az1=(raz/16384)*9.80;
     rt_kprintf("ax1 = %3d, ay1 = %3d, az1 = %3d ", ax1, ay1, az1 );
        //rt_thread_mdelay(1000);
   

   // mpu6xxx_deinit(dev);

    return 0;
}

void test_timer_01(void)
{
	/* 创建定时器1 */
	timer1 = rt_timer_create("timer1",  /* 定时器名字是 timer1 */
						jisuan, /* 超时时回调的处理函数 */
						RT_NULL,  /* 超时函数的入口参数 */
						1000,       /* 定时长度，以OS Tick为单位，即100个OS Tick */
						RT_TIMER_FLAG_PERIODIC); /* 周期性定时器 */
	/* 启动定时器 */
	if (timer1 != RT_NULL) rt_timer_start(timer1);

	
}
void ssd1306_wr(int sum_in )
{  
    ssd1306_Fill(Black);
    
    ssd1306_SetCursor(2, 26 );
    ssd1306_WriteString("jia su du he:", Font_7x10, White);
    
    char str[25];
 
  
    sprintf(str, "%d", sum_in); //将100转为16进制表示的字符串。
    ssd1306_SetCursor(95, 26 );

    ssd1306_WriteString(str, Font_7x10, White);

    ssd1306_UpdateScreen();
}

void heart_rate(void)
{
    int i;
    rt_device_t dev = rt_device_find("hr_max30102");
    if (dev == RT_NULL) {
        rt_kprintf("Find max30102 error");
        return ;
    }

    rt_device_open(dev, RT_DEVICE_FLAG_RDONLY);

    struct rt_sensor_data data;
    for (  i = 0; i < 10; i++) {
        if (rt_device_read(dev, 0, &data, sizeof(data)) == sizeof(data)) {
            rt_kprintf("heart rate: %d", data.data.hr);
        }
				rt_thread_mdelay(1000);
    }

    rt_device_close(dev);
}
int main()
{
  ssd1306_Init();

   
   
  mpu6xxx_st();
  getoffs();
  test_timer_01();
 rt_thread_mdelay(500);
 
  while (1)
  {
    mpu6xxx_test();
    rt_kprintf("%d",count);  rt_kprintf("%d",bai);  rt_kprintf("%d",shi);  rt_kprintf("%d",ge);


ssd1306_wr(sum);

  rt_thread_mdelay(1000);

 // heart_rate();
}
}


